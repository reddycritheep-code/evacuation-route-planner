from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health_and_demo_venue():
    assert client.get("/health").json()["status"] == "ok"
    response = client.get("/api/v1/venues/demo-building")
    assert response.status_code == 200
    venue = response.json()
    assert len(venue["nodes"]) >= 10
    assert len(venue["edges"]) >= 14
    assert {node["id"] for node in venue["nodes"] if node["type"] == "exit"} == {"west-exit", "east-exit"}


def test_route_is_returned_for_valid_start():
    response = client.post("/api/v1/routes", json={"startNodeId": "central"})
    assert response.status_code == 200
    body = response.json()
    assert body["routeFound"] is True
    assert body["route"]["exitId"] in {"west-exit", "east-exit"}
    assert body["route"]["nodeIds"][0] == "central"
    assert body["route"]["nodeIds"][-1] == body["route"]["exitId"]


def test_blocked_edge_is_not_used_and_alternate_route_exists():
    response = client.post(
        "/api/v1/routes",
        json={"startNodeId": "central", "blockedEdgeIds": ["central-east"]},
    )
    body = response.json()
    assert body["routeFound"] is True
    assert "central-east" not in body["route"]["edgeIds"]
    assert body["route"]["exitId"] == "west-exit"


def test_closed_exit_is_never_selected():
    response = client.post(
        "/api/v1/routes",
        json={"startNodeId": "central", "closedExitIds": ["west-exit"]},
    )
    body = response.json()
    assert body["routeFound"] is True
    assert body["route"]["exitId"] == "east-exit"
    assert all(item["exitId"] != "west-exit" for item in body["alternatives"])


def test_avoid_stairs_excludes_stairs_edge():
    response = client.post(
        "/api/v1/routes",
        json={"startNodeId": "north-room", "avoidStairs": True},
    )
    body = response.json()
    assert body["routeFound"] is True
    assert "north-room-stair" not in body["route"]["edgeIds"]


def test_no_route_is_explicit_when_all_edges_are_blocked():
    venue = client.get("/api/v1/venues/demo-building").json()
    edge_ids = [edge["id"] for edge in venue["edges"]]
    response = client.post(
        "/api/v1/routes",
        json={"startNodeId": "central", "blockedEdgeIds": edge_ids},
    )
    body = response.json()
    assert body["routeFound"] is False
    assert body["route"] is None
    assert "No modeled route" in body["message"]


def test_unknown_ids_are_rejected():
    assert client.post("/api/v1/routes", json={"startNodeId": "missing"}).status_code == 422
    assert client.post(
        "/api/v1/routes",
        json={"startNodeId": "central", "blockedEdgeIds": ["not-an-edge"]},
    ).status_code == 422
