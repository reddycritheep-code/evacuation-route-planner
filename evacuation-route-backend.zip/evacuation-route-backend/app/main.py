from __future__ import annotations

import os
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.data import VENUE
from app.routing import calculate_routes
from app.schemas import HealthResponse, RouteRequest, RouteResponse, VenueResponse

app = FastAPI(
    title="Emergency Evacuation Route Planner API",
    description=(
        "A prototype API for routing through a fictional sample venue. "
        "It uses static demo data and is not a certified life-safety system."
    ),
    version="1.0.0",
)

# Set CORS_ORIGINS to a comma-separated list in deployment, for example:
# CORS_ORIGINS=https://your-frontend.example
origins = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization"],
)


@app.get("/health", response_model=HealthResponse, tags=["system"])
def health() -> HealthResponse:
    return HealthResponse(status="ok", service="evacuation-route-planner-api")


@app.get("/api/v1/venues/{venue_id}", response_model=VenueResponse, tags=["venues"])
def get_venue(venue_id: str) -> VenueResponse:
    if venue_id != VENUE.id:
        raise HTTPException(status_code=404, detail="Venue not found")
    return VENUE


@app.post("/api/v1/routes", response_model=RouteResponse, tags=["routing"])
def get_routes(request: RouteRequest) -> RouteResponse:
    if request.venueId != VENUE.id:
        raise HTTPException(status_code=404, detail="Venue not found")

    node_ids = {node.id for node in VENUE.nodes}
    edge_ids = {edge.id for edge in VENUE.edges}
    exit_ids = {node.id for node in VENUE.nodes if node.type == "exit"}

    if request.startNodeId not in node_ids:
        raise HTTPException(status_code=422, detail=f"Unknown startNodeId: {request.startNodeId}")
    unknown_edges = sorted(set(request.blockedEdgeIds) - edge_ids)
    if unknown_edges:
        raise HTTPException(status_code=422, detail={"message": "Unknown blocked edge IDs", "ids": unknown_edges})
    unknown_exits = sorted(set(request.closedExitIds) - exit_ids)
    if unknown_exits:
        raise HTTPException(status_code=422, detail={"message": "Unknown closed exit IDs", "ids": unknown_exits})

    return calculate_routes(VENUE, request)
