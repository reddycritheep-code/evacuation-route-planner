from app.schemas import Edge, Node, VenueResponse

VENUE = VenueResponse(
    id="demo-building",
    name="Sample Community Center",
    description="Fictional single-floor map for a software demonstration.",
    units="meters (approximate)",
    nodes=[
        Node(id="west-exit", label="West Exit", x=5, y=50, type="exit", floor=1),
        Node(id="lobby", label="Lobby", x=18, y=50, type="room", floor=1),
        Node(id="west-junction", label="West Junction", x=33, y=50, type="junction", floor=1),
        Node(id="north-junction", label="North Junction", x=48, y=23, type="junction", floor=1),
        Node(id="central", label="Central Hall", x=52, y=50, type="room", floor=1),
        Node(id="south-junction", label="South Junction", x=48, y=77, type="junction", floor=1),
        Node(id="east-junction", label="East Junction", x=70, y=50, type="junction", floor=1),
        Node(id="east-lobby", label="East Lobby", x=84, y=50, type="room", floor=1),
        Node(id="east-exit", label="East Exit", x=97, y=50, type="exit", floor=1),
        Node(id="north-room", label="North Meeting Room", x=52, y=12, type="room", floor=1),
        Node(id="south-room", label="South Activity Room", x=52, y=88, type="room", floor=1),
    ],
    edges=[
        Edge(id="west-exit-link", fromNode="west-exit", toNode="lobby", label="west exit passage", distance=35, kind="corridor", accessible=True),
        Edge(id="west-main", fromNode="lobby", toNode="west-junction", label="west main corridor", distance=45, kind="corridor", accessible=True),
        Edge(id="west-north", fromNode="west-junction", toNode="north-junction", label="northwest corridor", distance=55, kind="corridor", accessible=True),
        Edge(id="west-south", fromNode="west-junction", toNode="south-junction", label="southwest corridor", distance=55, kind="corridor", accessible=True),
        Edge(id="north-central", fromNode="north-junction", toNode="central", label="north corridor", distance=50, kind="corridor", accessible=True),
        Edge(id="south-central", fromNode="south-junction", toNode="central", label="south corridor", distance=50, kind="corridor", accessible=True),
        Edge(id="central-east", fromNode="central", toNode="east-junction", label="central-east corridor", distance=45, kind="corridor", accessible=True),
        Edge(id="north-east", fromNode="north-junction", toNode="east-junction", label="northeast corridor", distance=70, kind="corridor", accessible=True),
        Edge(id="south-east", fromNode="south-junction", toNode="east-junction", label="southeast corridor", distance=70, kind="corridor", accessible=True),
        Edge(id="east-lobby-link", fromNode="east-junction", toNode="east-lobby", label="east lobby passage", distance=45, kind="corridor", accessible=True),
        Edge(id="east-exit-link", fromNode="east-lobby", toNode="east-exit", label="east exit passage", distance=35, kind="corridor", accessible=True),
        Edge(id="central-north-room", fromNode="central", toNode="north-room", label="north meeting room passage", distance=35, kind="corridor", accessible=True),
        Edge(id="central-south-room", fromNode="central", toNode="south-room", label="south activity room passage", distance=35, kind="corridor", accessible=True),
        Edge(id="north-room-stair", fromNode="north-room", toNode="north-junction", label="north room stair passage", distance=30, kind="stairs", accessible=False),
        Edge(id="south-room-link", fromNode="south-room", toNode="south-junction", label="south room ramp passage", distance=30, kind="ramp", accessible=True),
    ],
    safetyNotice=(
        "Prototype using simulated venue data. Follow venue staff and official emergency instructions."
    ),
)
