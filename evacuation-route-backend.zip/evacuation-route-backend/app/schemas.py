from __future__ import annotations

from typing import Literal
from pydantic import BaseModel, ConfigDict, Field


class Node(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    label: str
    x: float = Field(ge=0, le=100)
    y: float = Field(ge=0, le=100)
    type: Literal["room", "junction", "exit"]
    floor: int = Field(ge=0)


class Edge(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
    id: str
    fromNode: str = Field(alias="from")
    toNode: str = Field(alias="to")
    label: str
    distance: float = Field(gt=0)
    kind: Literal["corridor", "stairs", "ramp", "door"]
    accessible: bool = True


class VenueResponse(BaseModel):
    id: str
    name: str
    description: str
    units: str
    nodes: list[Node]
    edges: list[Edge]
    safetyNotice: str


class RouteRequest(BaseModel):
    venueId: str = "demo-building"
    startNodeId: str
    blockedEdgeIds: list[str] = Field(default_factory=list)
    closedExitIds: list[str] = Field(default_factory=list)
    avoidStairs: bool = False
    maxAlternatives: int = Field(default=2, ge=0, le=5)


class RoutePath(BaseModel):
    exitId: str
    exitLabel: str
    nodeIds: list[str]
    edgeIds: list[str]
    distance: float
    directions: list[str]


class RouteResponse(BaseModel):
    venueId: str
    startNodeId: str
    routeFound: bool
    route: RoutePath | None = None
    alternatives: list[RoutePath] = Field(default_factory=list)
    blockedEdgeIds: list[str]
    closedExitIds: list[str]
    avoidStairs: bool
    message: str


class HealthResponse(BaseModel):
    status: str
    service: str
