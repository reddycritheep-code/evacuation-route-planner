from __future__ import annotations

import heapq
from collections import defaultdict

from app.schemas import Edge, Node, RoutePath, RouteRequest, RouteResponse, VenueResponse


def _shortest_path(
    start: str,
    target: str,
    edges: list[Edge],
    blocked_edge_ids: set[str],
    avoid_stairs: bool,
) -> tuple[float, list[str], list[str]] | None:
    adjacency: dict[str, list[tuple[str, Edge]]] = defaultdict(list)
    for edge in edges:
        if edge.id in blocked_edge_ids:
            continue
        if avoid_stairs and (edge.kind == "stairs" or not edge.accessible):
            continue
        adjacency[edge.fromNode].append((edge.toNode, edge))
        adjacency[edge.toNode].append((edge.fromNode, edge))

    distances = {start: 0.0}
    previous: dict[str, tuple[str, Edge]] = {}
    queue: list[tuple[float, str]] = [(0.0, start)]

    while queue:
        distance, node_id = heapq.heappop(queue)
        if distance != distances.get(node_id):
            continue
        if node_id == target:
            break
        for neighbor, edge in adjacency[node_id]:
            candidate = distance + edge.distance
            if candidate < distances.get(neighbor, float("inf")):
                distances[neighbor] = candidate
                previous[neighbor] = (node_id, edge)
                heapq.heappush(queue, (candidate, neighbor))

    if target not in distances:
        return None

    node_path = [target]
    edge_path: list[str] = []
    cursor = target
    while cursor != start:
        prior, edge = previous[cursor]
        edge_path.append(edge.id)
        node_path.append(prior)
        cursor = prior
    node_path.reverse()
    edge_path.reverse()
    return distances[target], node_path, edge_path


def calculate_routes(venue: VenueResponse, request: RouteRequest) -> RouteResponse:
    nodes_by_id: dict[str, Node] = {node.id: node for node in venue.nodes}
    exits = [
        node for node in venue.nodes
        if node.type == "exit" and node.id not in set(request.closedExitIds)
    ]

    candidates: list[RoutePath] = []
    blocked = set(request.blockedEdgeIds)
    for exit_node in exits:
        result = _shortest_path(
            request.startNodeId,
            exit_node.id,
            venue.edges,
            blocked,
            request.avoidStairs,
        )
        if result is None:
            continue
        distance, node_ids, edge_ids = result
        candidates.append(
            RoutePath(
                exitId=exit_node.id,
                exitLabel=exit_node.label,
                nodeIds=node_ids,
                edgeIds=edge_ids,
                distance=round(distance, 2),
                directions=[f"Proceed via {edge.label}" for edge in _edges_for_path(edge_ids, venue.edges)],
            )
        )

    candidates.sort(key=lambda route: (route.distance, route.exitId))
    if not candidates:
        return RouteResponse(
            venueId=venue.id,
            startNodeId=request.startNodeId,
            routeFound=False,
            route=None,
            alternatives=[],
            blockedEdgeIds=sorted(blocked),
            closedExitIds=sorted(set(request.closedExitIds)),
            avoidStairs=request.avoidStairs,
            message="No modeled route to an open exit is available. Follow venue staff and official emergency instructions.",
        )

    # Return at most one route per exit, in ascending distance order.
    return RouteResponse(
        venueId=venue.id,
        startNodeId=request.startNodeId,
        routeFound=True,
        route=candidates[0],
        alternatives=candidates[1 : request.maxAlternatives + 1],
        blockedEdgeIds=sorted(blocked),
        closedExitIds=sorted(set(request.closedExitIds)),
        avoidStairs=request.avoidStairs,
        message="Route calculated from the fictional demo map. Distance is approximate.",
    )


def _edges_for_path(edge_ids: list[str], edges: list[Edge]) -> list[Edge]:
    by_id = {edge.id: edge for edge in edges}
    return [by_id[edge_id] for edge_id in edge_ids]
